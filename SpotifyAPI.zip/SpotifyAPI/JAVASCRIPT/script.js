document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        console.log(document.querySelector("#spotify-tracks"));  // Zorg ervoor dat de container aanwezig is
        console.log(document.querySelector("#spotify-artists")); // Zorg ervoor dat de container aanwezig is
    }, 1000);  // Wacht 1 seconde om ervoor te zorgen dat de DOM volledig is geladen

    
    const code = new URLSearchParams(window.location.search).get('code');
    const clientId = '717ab406658149eea3cc2e892ee4a74a';
    const clientSecret = 'aa5fdaffcd344ba78e95451898f92c9d';
    const redirectUri = 'http://127.0.0.1:5500/HTML/index.html';

    if (code) {
        const credentials = btoa(`${clientId}:${clientSecret}`);
        fetch('https://accounts.spotify.com/api/token', {
            method: 'POST',
            headers: {
                Authorization: `Basic ${credentials}`,
            },
            body: new URLSearchParams({
                grant_type: 'authorization_code',
                code: code,
                redirect_uri: redirectUri,
            }),
        })
            .then((response) => response.json())
            .then((data) => {
                const token = data.access_token;
                if (token) {
                    sessionStorage.setItem('spotifyToken', token);  // Sla de token op in sessionStorage
                    console.log('Spotify Token verkregen:', token);

                    // Redirect naar de juiste pagina nadat de token is verkregen
                    const currentPath = window.location.pathname;
                    if (currentPath.includes('top-artiesten.html')) {
                        fetchSpotifyData(token, 'me/top/artists', '#spotify-artists', renderArtists);
                    } else if (currentPath.includes('top-nummers.html')) {
                        fetchSpotifyData(token, 'me/top/tracks', '#spotify-tracks', renderTracks);
                    }
                } else {
                    console.error('Geen token ontvangen:', data);
                }
            })
            .catch((error) => console.error('Fout bij het verkrijgen van token:', error));
    } else {
        console.log('Geen code gevonden in de URL.');
        const savedToken = sessionStorage.getItem('spotifyToken');  // Verkrijg de token uit sessionStorage
        if (savedToken) {
            console.log('Token uit sessionStorage gebruikt.');
            const currentPath = window.location.pathname;
            if (currentPath.includes('top-artiesten.html')) {
                fetchSpotifyData(savedToken, 'me/top/artists', '#spotify-artists', renderArtists);
            } else if (currentPath.includes('top-nummers.html')) {
                fetchSpotifyData(savedToken, 'me/top/tracks', '#spotify-tracks', renderTracks);
            }
        else console.log('Geen opgeslagen token gevonden. in de actieve sessie.');  // Geen token in sessionStorage   
        }
    }

    function fetchSpotifyData(token, endpoint, containerSelector, renderFunction) {
        fetch(`https://api.spotify.com/v1/${endpoint}`, {
            headers: { Authorization: `Bearer ${token}` },
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.items) {
                    renderFunction(data.items, containerSelector);
                } else {
                    console.error('Geen data ontvangen:', data);
                }
            })
            .catch((error) => console.error(`Fout bij Spotify API-aanroep naar ${endpoint}:`, error));
    }

    function renderArtists(artists, containerSelector) {
        const container = document.querySelector(containerSelector);
        if (!container) {
            console.error(`Container niet gevonden: ${containerSelector}`);
            return;
        }

        if (!artists.length) {
            showError('Geen artiesten gevonden.', containerSelector);
            return;
        }
        container.innerHTML = artists
            .map(
                (artist) => `
                <div class="col-md-4">
                    <div class="card">
                        <img src="${artist.images[0]?.url || 'fallback-image.jpg'}" class="card-img-top" alt="Naam van de artiest: ${artist.name}">
                        <div class="card-body">
                            <h5 class="card-title">${artist.name}</h5>
                            <p>Genres: ${artist.genres.join(', ') || 'Onbekend'}</p>
                        </div>
                    </div>
                </div>`
            )
            .join('');
    }

    function renderTracks(tracks, containerSelector) {
        const container = document.querySelector(containerSelector);
        console.log(container)
        if (!container) {
            console.error(`Container niet gevonden: ${containerSelector}`);
            return;
        }
        
        if (!tracks.length) {
            showError('Geen nummers gevonden.', containerSelector);
            return;
        }

        container.innerHTML = tracks
            .map(
                (track) => `
                <div class="col-md-4">
                    <div class="card">
                        <img src="${track.album.images[0]?.url || 'fallback-image.jpg'}" class="card-img-top" alt="Naam van het nummer: ${track.name}">
                        <div class="card-body">
                            <h5 class="card-title">${track.name}</h5>
                            <p>Artiesten: ${track.artists.map((artist) => artist.name).join(', ')}</p>
                        </div>
                    </div>
                </div>`
            )
            .join('');
    }
    
    // Debug: Controleer of de container-elementen bestaan
    console.log(document.querySelector("#spotify-tracks")); // Moet het element tonen
    console.log(document.querySelector("#spotify-artists")); // Moet het element tonen

});

